
function controllo(){
    var email=document.getElementById('email').value;
    email=email.trim();
    if(email.lenght !=0 || !email.includes('@')){
        let index1= email.indexOf('@');
        let emailParts=email.split('@');
        console.log(emailParts[0]);
        if(emailParts[0].lenght >=1){
            let domain=emailParts[1].split('.');
            if(domain[0].lenght >=1){
                let afterDomain=domain[1];
                console.log(afterDomain);
                if(afterDomain.lenght >= 2){
                    document.getElementById('emailError').innerHTML = 'CORRECT';
                }else{
                    document.getElementById('emailError').innerHTML = 'DOMAIN NOT RIGHT'    
                }
            }else{
                document.getElementById('emailError').innerHTML = 'PREFIX DOMAIN NOT RIGHT';
            }
        }else{
            document.getElementById('emailError').innerHTML = 'LOCAL_PART NOT RIGHT';
        }
    }else{
        document.getElementById('emailError').innerHTML = 'EMPTY FIELD'
    }
    var password = document.getElementById('password').value;
    password=password.trim();
    if(password.lenght !=0){
        if(password.lenght >= 6){
            if(password.includes())[

            ]
        }else{
        document.getElementById('passError').innerHTML = 'PASSWORD TOO SHORT';
        }
    }else{
        document.getElementById('passError').innerHTML = 'EMPTY FIELD';
    }
}

